const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const E = require('./cone_reference_engine.cjs');
const load = name => JSON.parse(fs.readFileSync(path.join(__dirname, name), 'utf8'));
const pack = load('shadow_steps_levels_26_30_draft.json');
const report = load('validation_and_solutions.json');
assert.equal(pack.levels.length, 5);
for (let i = 0; i < pack.levels.length; i++) {
  const level = pack.levels[i];
  const expected = report.levels.find(r => r.label === level.label);
  assert.ok(expected, 'Missing validation entry');
  assert.equal(level.id, 31 + i);
  assert.equal(level.label, 'Level ' + (26 + i));
  assert.deepEqual(expected.errors, []);
  for (const mode of ['win', 'ghost']) {
    const solution = expected[mode];
    if (!solution) {
      assert.equal(mode, 'ghost');
      assert.equal(level.cams.length, 0);
      continue;
    }
    let state = E.begin(level);
    for (const action of solution.path) {
      const next = E.attempt(level, state, action);
      assert.ok(next.valid, level.label + ': invalid action');
      state = next.state;
    }
    assert.equal(state.result, 'win', level.label + ': failed replay');
    assert.equal(state.t, solution.actions);
    if (mode === 'ghost') assert.equal(state.alarmEver, false);
    const solved = E.search(level, { ghost: mode === 'ghost' });
    assert.equal(solved.status, 'win');
    assert.equal(solved.actions, solution.actions);
  }
  console.log(level.label + ': ' + level.optimalActions + ' actions; replay and shortest-path checks passed' + (expected.ghost ? '; Ghost passed' : ''));
}
console.log('Offline reference validation passed. This does not validate the live Unity project.');
