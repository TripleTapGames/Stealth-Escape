UNITY IMPORT HANDOFF

Place this entire extracted folder beside Assets in your Unity project, not inside Assets. Ask Claude Code to read CLAUDE_CODE_UNITY_IMPORT.txt and carry out that instruction. No direct Unity import has been performed here.

Run the included reference verifier with Node.js: node verify_reference.cjs
It uses only Node built-ins; no package installation is required.

SHADOW STEPS: LEVELS 26-30 — REVIEW DRAFT

Five additional main levels. Existing levels are untouched. IDs 31-35 follow the five FTUE levels and 25 main levels in the supplied schema. This is reference JSON, not a verified Unity import format.

Supplied V4 browser rules, with camera coverage replaced by a 70-degree cone of 2-node forward depth from the logical wall face; conservative opaque-cell/corner occlusion and closed-door LOS retained.
EMP and Smoke last two counted actions. Recheck detection on expiry. First alarm-triggering action does not consume its budget. Safe exit arrival wins before lockdown timeout.

Level 26 — Courtyard Relay | 7 x 9 | optimal 20 counted actions
A key retrieval and return through a rotating-guard zone, followed by a second timing gate.

Level 27 — Borrowed Cover | 7 x 9 | optimal 20 counted actions
A required Smoke crossing followed by a rotating guard; Smoke placement must leave the player safe when it expires.

Level 28 — Divided Watch | 9 x 9 | optimal 21 counted actions | Ghost 21
Two cameras with different schedules. EMP improves the shortest completion; Ghost is a separate objective.

Level 29 — Two Locks | 7 x 11 | optimal 24 counted actions | Ghost 24
Two mandatory locked connections use the same key, with a rotating guard, reversing patrol and fixed exit camera.

Level 30 — Inner Citadel | 9 x 11 | optimal 28 counted actions | Ghost 28
Two doors, two guards and two cameras combine with Smoke and EMP in three linked courtyards.

Validation includes initial safety, objective/guard placement, adjacent patrol paths, no locked-edge patrol crossings, guard occupancy over their full joint cycle, structural camera mounts, key gating, shortest completion and Ghost paths, route replay, and gadget removal checks. Read validation_and_solutions.json for results and exact actions (0=N, 1=E, 2=S, 3=W).

The camera cone uses forward depth, not radial distance. The supplied reference's 0.001-node wall-face offset is retained. Smoke and doors occlude sight; decorative camera mounts do not. Art mappings are proposals, not implemented assets.

Offline model only. Match Unity camera origins, occlusion and timing before importing. The reported Level 23 EMP-expiry failure remains unresolved in the live build.
