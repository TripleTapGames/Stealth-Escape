
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]], DN=['N','E','S','W'];
function at(p){return p[0]+','+p[1]}
function same(a,b){return a[0]===b[0]&&a[1]===b[1]}
function eq(a,b){return JSON.stringify(a)===JSON.stringify(b)}
function edgeID(a,b){return [at(a),at(b)].sort().join('|')}
function inside(L,p){return p[0]>=0&&p[0]<L.w&&p[1]>=0&&p[1]<L.h}
function floor(L,p){return inside(L,p)&&L.rows[p[1]][p[0]]!=='#'&&L.rows[p[1]][p[0]]!=='X'}
function wall(L,p){return !floor(L,p)}
function add(p,d){return [p[0]+DIRS[d][0],p[1]+DIRS[d][1]]}
function camDir(c,t){const first=DN.indexOf(c.dir);if(c.type==='rot')return (first+(c.ccw?-t:t)%4+4*1000)%4;if(c.type==='sweep')return Math.floor(t/2)%2? (first+(c.ccw?-1:1)+4)%4:first;return first}
function guardAt(g,t){if(g.type==='static'||g.type==='rot')return {p:g.at,dir:g.type==='rot'?(DN.indexOf(g.dir)+(g.ccw?-t:t)%4+4000)%4:DN.indexOf(g.dir)};
 let route=g.path;let n=route.length, period=g.type==='loop'?n:2*(n-1), k=(t+g.offset)%period;
 let current=g.type==='loop'?k:(k<n?k:period-k), prevk=(t+g.offset-1+period)%period, prev=g.type==='loop'?prevk:(prevk<n?prevk:period-prevk), nextk=(t+g.offset+1)%period,next=g.type==='loop'?nextk:(nextk<n?nextk:period-nextk);
 let p=route[current],from=route[prev];let d=DIRS.findIndex(q=>p[0]-from[0]===q[0]&&p[1]-from[1]===q[1]);if(d<0){let q=route[next];d=DIRS.findIndex(v=>q[0]-p[0]===v[0]&&q[1]-p[1]===v[1]);}return {p,dir:Math.max(0,d)};
}
function cellsAlong(a,b){return null}
// Conservative segment/rectangle intersection: touching an edge or corner counts as blocked.
function hitsRect(a,b,x,y){const EPS=1e-8;let t0=0,t1=1;let bounds=[[x-.5,x+.5],[y-.5,y+.5]];for(let axis=0;axis<2;axis++){const delta=b[axis]-a[axis],lo=bounds[axis][0],hi=bounds[axis][1];if(Math.abs(delta)<EPS){if(a[axis]<lo-EPS||a[axis]>hi+EPS)return false;}else{let u=(lo-a[axis])/delta,v=(hi-a[axis])/delta;if(u>v)[u,v]=[v,u];t0=Math.max(t0,u);t1=Math.min(t1,v);if(t0>t1+EPS)return false;}}return t1>=-EPS&&t0<=1+EPS}
function segmentsMeet(a,b,c,d){const x1=a[0],y1=a[1],x2=b[0],y2=b[1],x3=c[0],y3=c[1],x4=d[0],y4=d[1];let cross=(u,v,w)=> (v[0]-u[0])*(w[1]-u[1])-(v[1]-u[1])*(w[0]-u[0]);let s1=cross(a,b,c),s2=cross(a,b,d),s3=cross(c,d,a),s4=cross(c,d,b);return s1*s2<=1e-9&&s3*s4<=1e-9&&Math.max(Math.min(x1,x2),Math.min(x3,x4))<=Math.min(Math.max(x1,x2),Math.max(x3,x4))+1e-8&&Math.max(Math.min(y1,y2),Math.min(y3,y4))<=Math.min(Math.max(y1,y2),Math.max(y3,y4))+1e-8}
function obstructed(L,s,a,b){for(let y=0;y<L.h;y++)for(let x=0;x<L.w;x++){if(L.rows[y][x]!=='#'&&L.rows[y][x]!=='X')continue; // Both solid walls and blocked cover nodes obstruct sight.
 if(hitsRect(a,b,x,y))return true;}
 for(let i=0;i<(L.doors||[]).length;i++){let door=L.doors[i];if(s.open&(1<<i))continue;let p=door.a,q=door.b;let mid=[(p[0]+q[0])/2,(p[1]+q[1])/2],dx=q[0]-p[0],dy=q[1]-p[1],v=[-dy*.48,dx*.48];if(segmentsMeet(a,b,[mid[0]-v[0],mid[1]-v[1]],[mid[0]+v[0],mid[1]+v[1]]))return true;}
 return false}
function smoked(s,p){return s.smokes.some(c=>same(c.p,p))}
function guardSees(L,s,g){let {p,dir}=g;if(smoked(s,p))return false;for(let k=1;k<=2;k++){let q=[p[0]+DIRS[dir][0]*k,p[1]+DIRS[dir][1]*k];if(!inside(L,q)||obstructed(L,s,p,q)||smoked(s,q))return (same(s.p,q)&&!obstructed(L,s,p,q))?false:false;if(same(s.p,q))return true;}return false}
function guardVision(L,s,g){let out=[];let {p,dir}=g;if(smoked(s,p))return out;for(let k=1;k<=2;k++){let q=[p[0]+DIRS[dir][0]*k,p[1]+DIRS[dir][1]*k];if(!floor(L,q)||obstructed(L,s,p,q)||smoked(s,q))break;out.push(q);}return out}
function camPos(c){let d=DN.indexOf(c.mountDir||c.dir),v=DIRS[d];return [c.wall[0]+v[0]*.501,c.wall[1]+v[1]*.501]}
function camVision(L,s,c,t,allowDisabled=false){if(!allowDisabled&&s.emps.some(e=>e.id===L.cams.indexOf(c)))return [];let origin=camPos(c),d=camDir(c,t),v=DIRS[d],side=[-v[1],v[0]],out=[];let cent=[Math.round(origin[0]),Math.round(origin[1])];for(let forward=1;forward<=2;forward++)for(let lane=-1;lane<=1;lane++){let p=[cent[0]+v[0]*forward+side[0]*lane,cent[1]+v[1]*forward+side[1]*lane];if(!floor(L,p))continue;if(obstructed(L,s,origin,p))continue;if(s.smokes.some(cl=>hitsRect(origin,p,cl.p[0],cl.p[1])))continue;out.push(p);}return out}
function cameraSees(L,s,t){for(let i=0;i<(L.cams||[]).length;i++){if(s.emps.some(e=>e.id===i))continue;if(camVision(L,s,L.cams[i],t).some(q=>same(q,s.p)))return true;}return false}
function occupants(L,t){return (L.guards||[]).map(g=>guardAt(g,t))}
function begin(L){return {p:[...L.start],t:0,key:false,open:0,smokes:[],emps:[],smokeLeft:L.smoke||0,empLeft:L.emp||0,alarm:-1,alarmEver:false,result:'',cause:''}}
function attempt(L,st,action){let s={...st,p:[...st.p],smokes:st.smokes.map(x=>({...x,p:[...x.p]})),emps:st.emps.map(x=>({...x}))};if(s.result)return {state:s,valid:false};const bad=(why)=>({state:s,valid:false,why});if(action.type==='smoke'){let p=action.p;if(!s.smokeLeft||!floor(L,p)||Math.max(Math.abs(p[0]-s.p[0]),Math.abs(p[1]-s.p[1]))>1||smoked(s,p)||obstructed(L,s,s.p,p))return bad('Cannot place Smoke there');s.smokeLeft--;s.smokes.push({p:[...p],left:2});return {state:s,valid:true,free:true}}if(action.type==='emp'){let id=action.id;if(!s.empLeft||!L.cams||!L.cams[id]||s.emps.some(e=>e.id===id))return bad('Camera unavailable');s.empLeft--;s.emps.push({id,left:2});return {state:s,valid:true,free:true}}let old=s.p, target=old;if(action.type==='move'){target=add(old,action.dir);if(!floor(L,target))return bad('Blocked');if(L.cuts?.includes(edgeID(old,target)))return bad('No connection');let doorId=(L.doors||[]).findIndex(d=>edgeID(d.a,d.b)===edgeID(old,target));if(doorId>=0&&!(s.open&(1<<doorId))){if(!s.key)return bad('A key is required');s.open|=(1<<doorId)}s.p=target;}else if(action.type!=='wait')return bad('Unknown action');
 // Key pickup takes place upon entry, before enemy resolution.
 if(L.key&&same(s.p,L.key))s.key=true;
 const oldG=occupants(L,s.t),nextG=occupants(L,s.t+1);let fail=(cause)=>{s.result='caught';s.cause=cause;return {state:s,valid:true}};
 if(oldG.some(g=>same(g.p,s.p)))return fail('Guard collision');
 if(oldG.some(g=>guardVision(L,s,g).some(q=>same(q,s.p))))return fail('Guard saw you before moving');
 let activated=false;const trigger=()=>{if(s.alarm<0){s.alarm=L.budget||4;s.alarmEver=true;activated=true;}};
 if(cameraSees(L,s,s.t))trigger();
 if(nextG.some((g,i)=>same(g.p,s.p)||(same(oldG[i].p,s.p)&&same(g.p,old))))return fail('Guard collision');
 if(nextG.some(g=>guardVision(L,s,g).some(q=>same(q,s.p))))return fail('Guard saw you after moving');
 if(cameraSees(L,s,s.t+1))trigger();
 s.t++;
 if(s.alarm>=0&&!activated)s.alarm--;
 // Victory is after the whole normal enemy update, before expiring gadget checks.
 if(same(s.p,L.exit)){s.result='win';return {state:s,valid:true}};
 s.smokes=s.smokes.map(v=>({...v,left:v.left-1})).filter(v=>v.left>0);
 s.emps=s.emps.map(v=>({...v,left:v.left-1})).filter(v=>v.left>0);
 if(nextG.some(g=>guardVision(L,s,g).some(q=>same(q,s.p))))return fail('Smoke expired — guard spotted you');
 if(cameraSees(L,s,s.t))trigger();
 if(s.alarm===0){s.result='lockdown';s.cause='Lockdown timer expired';}
 return {state:s,valid:true};}
function stateHash(s){return [at(s.p),s.t,s.key?1:0,s.open,s.smokeLeft,s.empLeft,s.smokes.map(z=>at(z.p)+':'+z.left).sort().join(';'),s.emps.map(z=>z.id+':'+z.left).sort().join(';'),s.alarm,s.alarmEver?1:0].join('/')}
function solve(L,{noSmoke=false,noEMP=false,ghost=false,maxTurns=30,limit=130000}={}){let front=[begin(L)],seen=new Set(),visited=0;front[0].smokeLeft=noSmoke?0:front[0].smokeLeft;front[0].empLeft=noEMP?0:front[0].empLeft;
 for(let t=0;t<=maxTurns;t++){
  let expanded=[],queue=[...front];for(let qi=0;qi<queue.length;qi++){
   let s=queue[qi],h=stateHash(s);if(seen.has(h))continue;seen.add(h);visited++;if(visited>limit)return {status:'limit',visited};expanded.push(s);
   if(s.smokeLeft){for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){let p=[s.p[0]+dx,s.p[1]+dy],v=attempt(L,s,{type:'smoke',p});if(v.valid)queue.push(v.state)}}
   if(s.empLeft)for(let i=0;i<(L.cams||[]).length;i++){let v=attempt(L,s,{type:'emp',id:i});if(v.valid)queue.push(v.state)}
  }
  let next=[];for(let s of expanded)for(let action of [{type:'wait'},...DIRS.map((_,dir)=>({type:'move',dir}))]){let v=attempt(L,s,action);if(!v.valid)continue;if(ghost&&v.state.alarmEver)continue;if(v.state.result==='win')return {status:'win',optimal:v.state.t,visited};if(!v.state.result)next.push(v.state)}front=next;if(!front.length)return {status:'none',visited};
 }
 return {status:'max',visited};}
const API={DIRS,DN,at,same,edgeID,inside,floor,add,camDir,guardAt,obstructed,guardVision,camVision,begin,attempt,solve};


function coneCamera(L,s,c,t,allowDisabled=false){
 if(!allowDisabled&&s.emps.some(e=>e.id===L.cams.indexOf(c)))return [];
 const origin=camPos(c),v=DIRS[camDir(c,t)],out=[];
 for(let y=0;y<L.h;y++)for(let x=0;x<L.w;x++){
  const p=[x,y],dx=x-origin[0],dy=y-origin[1],forward=dx*v[0]+dy*v[1],side=-dx*v[1]+dy*v[0];
  if(!floor(L,p)||forward<=0||forward>2+1e-9||Math.abs(side)>forward*Math.tan(35*Math.PI/180)+1e-9)continue;
  if(obstructed(L,s,origin,p)||s.smokes.some(cl=>hitsRect(origin,p,cl.p[0],cl.p[1])))continue;
  out.push(p);
 }
 return out;
}
function search(L,{ghost=false,noSmoke=false,noEMP=false,noWait=false,maxTurns=256,limit=200000}={}){
 let init=begin(L);if(noSmoke)init.smokeLeft=0;if(noEMP)init.empLeft=0;
 const gcd=(a,b)=>b?gcd(b,a%b):a;
 const periods=[...L.guards.map(g=>g.type==='loop'?g.path.length:g.type==='bounce'?2*(g.path.length-1):g.type==='rot'?4:1),...L.cams.map(c=>c.type==='fixed'?1:4)];
 const period=periods.reduce((a,b)=>a*b/gcd(a,b),1);
 let front=[{s:init,path:[]}],seen=new Set(),visited=0;
 for(let t=0;t<=maxTurns;t++){
  const expanded=[],queue=[...front];
  for(let qi=0;qi<queue.length;qi++){
   const z=queue[qi],s=z.s,k=stateHash({...s,t:s.t%period});if(seen.has(k))continue;seen.add(k);visited++;
   if(visited>limit)return {status:'limit',visited};expanded.push(z);
   const free=[];
   if(s.smokeLeft)for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)free.push({type:'smoke',p:[s.p[0]+dx,s.p[1]+dy]});
   if(s.empLeft)for(let id=0;id<L.cams.length;id++)free.push({type:'emp',id});
   for(const a of free){const v=attempt(L,s,a);if(v.valid)queue.push({s:v.state,path:[...z.path,a]});}
  }
  const next=[],actions=[...(noWait?[]:[{type:'wait'}]),...DIRS.map((_,dir)=>({type:'move',dir}))];
  for(const z of expanded)for(const a of actions){
   const v=attempt(L,z.s,a);if(!v.valid||ghost&&v.state.alarmEver)continue;
   const path=[...z.path,a];
   if(v.state.result==='win')return {status:'win',actions:v.state.t,waits:path.filter(a=>a.type==='wait').length,smoke:path.filter(a=>a.type==='smoke').length,emp:path.filter(a=>a.type==='emp').length,alarm:v.state.alarmEver,visited,path};
   if(!v.state.result)next.push({s:v.state,path});
  }
  front=next;if(!front.length)return {status:'none',visited};
 }
 return {status:'maxTurns',visited};
}

camVision=coneCamera;module.exports={search,begin,attempt,guardAt,guardVision,camVision:coneCamera,camPos,camDir,floor,edgeID,obstructed,DN,DIRS};
