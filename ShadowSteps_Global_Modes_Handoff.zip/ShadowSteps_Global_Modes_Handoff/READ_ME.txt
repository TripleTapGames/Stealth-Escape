SHADOW STEPS — GLOBAL STEALTH / KNOCKOUT HANDOFF

This handoff supersedes the earlier Level-26-only rollout. The Stealth/Knockout toggle applies to ALL available levels through the shared game engine: existing FTUE/main content, installed expansions, and future levels using that engine. Level 26 remains a regression example only.

Extract this folder beside Assets in the Unity project. Ask Claude Code to read START_HERE_CLAUDE_CODE.txt and carry out the implementation.

Stealth: original gameplay, no knockouts.
Knockout: moving onto an adjacent guard from behind or a side knocks it out; player ends on the enemy node; the whole action costs one turn. Frontal attempts are unavailable. Other hazards resolve at the landing node.

Changing mode restarts the current level. Retry and Next Level retain the chosen mode. Clicking the current mode does not restart. Existing unlocked levels remain available in both modes; recorded results are separate per mode. Old saves retain their original Stealth results.

This package changes the FEATURE SCOPE, not the level layouts. Do not import or overwrite Unity levels from the included reference snapshot. It is only an audit dataset and contains older pre-cone layouts as well as newer expansion drafts. The actual Unity project is authoritative.

FILES
START_HERE_CLAUDE_CODE.txt: canonical global implementation instruction.
mode_configuration.json: design contract to map into Unity, not a drop-in asset.
combat_reference_engine.cjs / stealth_reference_engine.cjs: executable offline rule comparisons.
verify_combat.cjs: focused behavior checks using Level 26 and small interaction fixtures.
level_26_combat_prototype.json / validation_and_solutions.json: regression fixture only, not a feature restriction.
verify_all_levels.cjs: audit all 35 reference stages in both modes.
reference_levels_for_audit.json: offline snapshot only; not an import request.
all_modes_validation.json: per-stage/per-mode paths, results and caveats.
manifest.json: package checksums and summary.

Run: node verify_combat.cjs
Run: node verify_all_levels.cjs
No dependency installation is needed.

Unity implementation and runtime validation remain pending. Original reference Main 18 and 19 were already unsolved under the cone model in Stealth; both have no guards. That pre-existing snapshot issue is not a reason to limit the toggle or silently change current Unity layouts. The user-reported Main 23 EMP-expiry failure also needs actual Unity inspection.
