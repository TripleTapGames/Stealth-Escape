'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const B=require('./stealth_reference_engine.cjs'),C=require('./combat_reference_engine.cjs');
const {levels}=JSON.parse(fs.readFileSync(path.join(__dirname,'reference_levels_for_audit.json')));
const rows=[];
function replay(L,r,mode,ghost){
 if(r.status!=='win')return;
 let state=C.begin(L),baseline=mode==='stealth'?B.begin(L):null;
 for(const action of r.path){
  const result=C.attempt(L,state,action,{combat:mode==='knockout'});assert.equal(result.valid,true,L.label+': invalid replay');state=result.state;
  if(baseline){const b=B.attempt(L,baseline,action);assert.equal(b.valid,true);baseline=b.state;const {defeated,...rest}=state;assert.equal(defeated,0);assert.deepEqual(rest,baseline,L.label+': stealth divergence');}
 }
 assert.equal(state.result,'win');assert.equal(state.t,r.actions);if(ghost)assert.equal(state.alarmEver,false);
}
for(const L of levels){
 const baseline=B.search(L),stealth=C.search(L,{combat:false}),knockout=C.search(L,{combat:true});
 for(const r of [baseline,stealth,knockout])assert.ok(['win','none'].includes(r.status),L.label+': search cap reached');
 assert.equal(stealth.status,baseline.status);assert.equal(stealth.actions,baseline.actions);
 if(stealth.status==='win'){assert.equal(knockout.status,'win');assert.ok(knockout.actions<=stealth.actions);}
 if(!L.guards.length){assert.equal(knockout.status,stealth.status);assert.equal(knockout.actions,stealth.actions);}
 const stealthGhost=L.cams.length?C.search(L,{combat:false,ghost:true}):null;
 const knockoutGhost=L.cams.length?C.search(L,{combat:true,ghost:true}):null;
 for(const r of [stealthGhost,knockoutGhost].filter(Boolean))assert.ok(['win','none'].includes(r.status));
 replay(L,stealth,'stealth',false);replay(L,knockout,'knockout',false);
 if(stealthGhost)replay(L,stealthGhost,'stealth',true);
 if(knockoutGhost)replay(L,knockoutGhost,'knockout',true);
 rows.push({id:L.id,label:L.label,title:L.title,guardCount:L.guards.length,stealth,knockout,stealthGhost,knockoutGhost});
}
const summary={levels:rows.length,stealthWins:rows.filter(r=>r.stealth.status==='win').length,knockoutWins:rows.filter(r=>r.knockout.status==='win').length,shorterWithKnockouts:rows.filter(r=>r.stealth.status==='win'&&r.knockout.actions<r.stealth.actions).map(r=>({label:r.label,stealth:r.stealth.actions,knockout:r.knockout.actions})),preExistingNoSolution:rows.filter(r=>r.stealth.status==='none').map(r=>r.label),stealthStateParity:'passed for every replayed winning path',searchCapsHit:0};
const report={scope:'Offline reference snapshot, not Unity runtime validation. The old V4 camera layouts may differ from current Unity content. No layouts modified.',summary,levels:rows};
fs.writeFileSync(path.join(__dirname,'all_modes_validation.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(summary,null,2));
