'use strict';
function createCombatEngine(B) {
  const same=(a,b)=>a[0]===b[0]&&a[1]===b[1];
  const count=n=>{let k=0;while(n){k+=n&1;n>>>=1;}return k;};
  const alive=(s,i)=>!((s.defeated||0)&(1<<i));
  const activeLevel=(L,s)=>({...L,guards:L.guards.filter((g,i)=>alive(s,i))});
  const begin=L=>({...B.begin(L),defeated:0});
  function attackCheck(L,s,id,{combat=true}={}) {
    if(s.result)return {valid:false,why:'The level has ended.'};
    if(!combat)return {valid:false,why:'Attacks are disabled in the original stealth version.'};
    if(!Number.isInteger(id)||id<0||id>=L.guards.length)return {valid:false,why:'Choose a guard.'};
    if(!alive(s,id))return {valid:false,why:'This guard is already knocked out.'};
    const g=B.guardAt(L.guards[id],s.t),dx=s.p[0]-g.p[0],dy=s.p[1]-g.p[1];
    if(Math.abs(dx)+Math.abs(dy)!==1)return {valid:false,why:'Stand on a directly adjacent node.'};
    if(L.cuts?.includes(B.edgeID(s.p,g.p)))return {valid:false,why:'There is no connection to this guard.'};
    const door=L.doors.findIndex(d=>B.edgeID(d.a,d.b)===B.edgeID(s.p,g.p));
    if(door>=0&&!(s.open&(1<<door)))return {valid:false,why:'A closed door blocks the attack.'};
    if(B.obstructed(L,s,s.p,g.p))return {valid:false,why:'Solid cover blocks the attack.'};
    const forward=B.DIRS[g.dir],dot=dx*forward[0]+dy*forward[1];
    if(dot===1)return {valid:false,why:'Frontal attacks are unavailable.'};
    // Positive projection onto the guard's right vector is its right side.
    const side=dx*(-forward[1])+dy*forward[0];
    return {valid:true,side:dot===-1?'back':side===1?'right':'left',guardPosition:g.p,guardFacing:g.dir};
  }
  function attempt(L,s,action,options={}) {
    // Every combat input that enters a live guard resolves through one rule.
    if(action.type==='move'&&options.combat!==false&&Number.isInteger(action.dir)&&B.DIRS[action.dir]){
      const d=B.DIRS[action.dir],target=[s.p[0]+d[0],s.p[1]+d[1]];
      const id=L.guards.findIndex((g,i)=>alive(s,i)&&same(B.guardAt(g,s.t).p,target));
      if(id>=0)action={type:'attack',id};
    }
    if(action.type==='attack'){
      const check=attackCheck(L,s,action.id,options);
      if(!check.valid)return {valid:false,state:structuredClone(s),why:check.why};
      const next={...s,defeated:(s.defeated||0)|(1<<action.id)};
      // Remove the target and enter its CURRENT node as a single counted move.
      // Remaining hazards evaluate the new player position before and after
      // their update; never run a second counted action for the knockout.
      const dir=B.DIRS.findIndex(d=>same([s.p[0]+d[0],s.p[1]+d[1]],check.guardPosition));
      const result=B.attempt(activeLevel(L,next),next,{type:'move',dir});
      return {...result,attack:{id:action.id,side:check.side,from:[...s.p],target:[...check.guardPosition],facing:check.guardFacing}};
    }
    return B.attempt(activeLevel(L,s),s,action);
  }
  function search(L,{combat=true,minKnockouts=0,maxKnockouts=Infinity,ghost=false,maxTurns=256,limit=200000}={}) {
    const gcd=(a,b)=>b?gcd(b,a%b):a;
    const period=[...L.guards.map(g=>g.type==='rot'?4:g.type==='bounce'?2*(g.path.length-1):g.type==='loop'?g.path.length:1),...L.cams.map(c=>c.type==='fixed'?1:4)].reduce((a,b)=>a*b/gcd(a,b),1);
    const hash=s=>JSON.stringify([s.p,s.t%period,s.defeated,s.key,s.open,s.smokeLeft,s.empLeft,s.smokes,s.emps,s.alarm,s.alarmEver]);
    let front=[{s:begin(L),path:[]}],seen=new Set(),visited=0;
    for(let turn=0;turn<maxTurns;turn++){
      const expanded=[],queue=[...front];
      for(let j=0;j<queue.length;j++){
        const z=queue[j],s=z.s,k=hash(s);if(seen.has(k))continue;seen.add(k);if(++visited>limit)return {status:'limit',visited};expanded.push(z);
        const free=[];
        if(s.smokeLeft)for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)free.push({type:'smoke',p:[s.p[0]+dx,s.p[1]+dy]});
        if(s.empLeft)L.cams.forEach((c,id)=>free.push({type:'emp',id}));
        for(const action of free){const r=attempt(L,s,action,{combat});if(r.valid)queue.push({s:r.state,path:[...z.path,action]});}
      }
      const next=[];
      for(const z of expanded){
        const actions=[{type:'wait'},...B.DIRS.map((_,dir)=>({type:'move',dir})),...(combat?L.guards.map((g,id)=>({type:'attack',id})):[])];
        for(const action of actions){
          const r=attempt(L,z.s,action,{combat});if(!r.valid||(ghost&&r.state.alarmEver)||count(r.state.defeated)>maxKnockouts)continue;
          const path=[...z.path,r.attack?{type:'attack',id:r.attack.id}:action];
          if(r.state.result==='win'){
            if(count(r.state.defeated)<minKnockouts)continue;
            return {status:'win',actions:r.state.t,knockouts:count(r.state.defeated),waits:path.filter(a=>a.type==='wait').length,visited,path};
          }
          if(!r.state.result)next.push({s:r.state,path});
        }
      }
      front=next;if(!front.length)return {status:'none',visited};
    }
    return {status:'maxTurns',visited};
  }
  return {begin,attempt,attackCheck,activeLevel,alive,count,search};
}
if(typeof module!=='undefined'&&module.exports){module.exports=createCombatEngine(require('./stealth_reference_engine.cjs'));module.exports.createCombatEngine=createCombatEngine;}
