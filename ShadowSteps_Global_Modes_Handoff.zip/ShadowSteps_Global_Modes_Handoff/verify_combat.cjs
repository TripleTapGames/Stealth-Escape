'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const B=require('./stealth_reference_engine.cjs'),C=require('./combat_reference_engine.cjs');
const fixture=(overrides={})=>({w:5,h:5,rows:Array(5).fill('.....'),start:[3,2],exit:[4,4],key:null,guards:[{type:'static',at:[2,2],dir:'N'}],cams:[],doors:[],cuts:[],smoke:0,emp:0,budget:1,...overrides});
let checks=0;
const check=(name,fn)=>{fn();checks++;};
for(let facing=0;facing<4;facing++)for(let relative=0;relative<4;relative++)check('facing '+facing+' approach '+relative,()=>{
 const d=B.DIRS[relative],L=fixture({start:[2+d[0],2+d[1]],guards:[{type:'static',at:[2,2],dir:B.DN[facing]}]}),s=C.begin(L),before=JSON.stringify(s),r=C.attempt(L,s,{type:'attack',id:0});
 assert.equal(r.valid,facing!==relative);assert.equal(JSON.stringify(s),before);
 if(r.valid){assert.equal(r.state.t,1);assert.deepEqual(r.state.p,[2,2]);assert.equal(r.state.defeated,1);assert.equal(r.state.result,'');}
 else {assert.deepEqual(r.state,s);assert.match(r.why,/Frontal/);}
});
check('diagonal and distant attacks rejected',()=>{
 for(const start of [[3,3],[4,2]]){const L=fixture({start}),s=C.begin(L),r=C.attempt(L,s,{type:'attack',id:0});assert.equal(r.valid,false);assert.deepEqual(r.state,s);}
});
check('closed door cannot be attacked through even with key',()=>{
 const L=fixture({doors:[{a:[2,2],b:[3,2]}]}),s={...C.begin(L),key:true};assert.equal(C.attackCheck(L,s,0).valid,false);
 s.open=1;assert.equal(C.attackCheck(L,s,0).valid,true);
});
check('missing movement edge blocks attack',()=>{
 const L=fixture({cuts:['2,2|3,2']});assert.equal(C.attackCheck(L,C.begin(L),0).valid,false);
});
check('Smoke does not enable frontal attack',()=>{
 const L=fixture({start:[2,1]}),s=C.begin(L);s.smokes=[{p:[2,1],left:2}];assert.equal(C.attackCheck(L,s,0).valid,false);
});
check('moving guard uses current facing before reversal',()=>{
 const L=fixture({start:[2,2],guards:[{type:'bounce',path:[[1,2],[2,2],[3,2]],offset:0}]}),s=C.begin(L);
 assert.equal(B.guardAt(L.guards[0],0).dir,3);assert.equal(C.attackCheck(L,s,0).side,'back');
 assert.equal(C.attempt(L,s,{type:'attack',id:0}).state.result,'');
 s.p=[0,2];assert.equal(C.attackCheck(L,s,0).valid,false);
});
check('target removal precedes its turn but other guards advance',()=>{
 const L=fixture({guards:[{type:'rot',at:[2,2],dir:'N'},{type:'rot',at:[0,0],dir:'N'}]}),r=C.attempt(L,C.begin(L),{type:'attack',id:0});
 assert.equal(r.state.t,1);assert.equal(C.activeLevel(L,r.state).guards.length,1);assert.equal(B.guardAt(L.guards[1],r.state.t).dir,1);
});
check('another guard can catch the attacker',()=>{
 const L=fixture({guards:[{type:'static',at:[2,2],dir:'N'},{type:'static',at:[4,2],dir:'W'}]}),r=C.attempt(L,C.begin(L),{type:'attack',id:0});assert.equal(r.state.result,'caught');
});
check('knockout persists, vacated node is traversable',()=>{
 const L=fixture();let s=C.attempt(L,C.begin(L),{type:'attack',id:0}).state;
 assert.equal(C.attempt(L,s,{type:'attack',id:0}).valid,false);
 assert.deepEqual(s.p,[2,2]);
 s=C.attempt(L,s,{type:'move',dir:3}).state;assert.deepEqual(s.p,[1,2]);
 s=C.attempt(L,s,{type:'move',dir:1}).state;assert.deepEqual(s.p,[2,2]);assert.equal(s.result,'');
 for(let i=0;i<12;i++)s=C.attempt(L,s,{type:'wait'}).state;
 assert.equal(s.defeated,1);assert.equal(s.result,'');
});
check('combat movement into a guard matches a targeted knockout',()=>{
 const L=fixture(),s=C.begin(L),move=C.attempt(L,s,{type:'move',dir:3}),hit=C.attempt(L,s,{type:'attack',id:0});
 assert.deepEqual(move,hit);assert.deepEqual(move.state.p,[2,2]);assert.equal(move.state.t,1);
});
check('frontal combat entry is rejected without consuming a turn',()=>{
 const L=fixture({start:[2,1]}),s=C.begin(L),r=C.attempt(L,s,{type:'move',dir:2});assert.equal(r.valid,false);assert.deepEqual(r.state,s);
});
check('original stealth collision remains fatal',()=>{
 const L=fixture(),r=C.attempt(L,C.begin(L),{type:'move',dir:3},{combat:false});assert.equal(r.state.result,'caught');
});
check('remaining guard can capture at landing node after its rotation',()=>{
 const L=fixture({guards:[{type:'static',at:[2,2],dir:'N'},{type:'rot',at:[2,3],dir:'W'}]}),r=C.attempt(L,C.begin(L),{type:'attack',id:0});assert.equal(r.state.result,'caught');assert.match(r.state.cause,/after moving/);
});
check('post-update vision at the vacated player node is not capture',()=>{
 const L=fixture({guards:[{type:'static',at:[2,2],dir:'N'},{type:'rot',at:[3,4],dir:'W'}]}),r=C.attempt(L,C.begin(L),{type:'attack',id:0});assert.equal(r.state.result,'');assert.deepEqual(r.state.p,[2,2]);
});
check('attacks disabled in stealth mode',()=>{
 const L=fixture(),s=C.begin(L),r=C.attempt(L,s,{type:'attack',id:0},{combat:false});assert.equal(r.valid,false);assert.deepEqual(r.state,s);
});
check('attack advances both gadget durations',()=>{
 const L=fixture({cams:[{wall:[0,0],mountDir:'S',dir:'S',type:'rot'}]}),s=C.begin(L);s.smokes=[{p:[4,4],left:2}];s.emps=[{id:0,left:2}];
 const r=C.attempt(L,s,{type:'attack',id:0});assert.equal(r.state.smokes[0].left,1);assert.equal(r.state.emps[0].left,1);assert.equal(B.camDir(L.cams[0],r.state.t),3);
});
check('expiry on attack starts full lockdown; last-action exit wins',()=>{
 const L=fixture({start:[2,1],exit:[4,1],guards:[{type:'static',at:[3,1],dir:'N'}],cams:[{wall:[3,0],mountDir:'S',dir:'S',type:'fixed'}]}),s=C.begin(L);s.emps=[{id:0,left:1}];
 const r=C.attempt(L,s,{type:'attack',id:0});assert.equal(r.state.result,'');assert.equal(r.state.alarm,1);assert.equal(r.state.t,1);assert.equal(r.state.emps.length,0);
 const end=C.attempt(L,r.state,{type:'move',dir:1});assert.equal(end.state.result,'win');assert.equal(end.state.alarm,0);
});
check('Smoke expiry after attack can cause capture',()=>{
 const L=fixture({guards:[{type:'static',at:[2,2],dir:'N'},{type:'static',at:[2,4],dir:'N'}]}),s=C.begin(L);s.smokes=[{p:[2,2],left:1}];
 const r=C.attempt(L,s,{type:'attack',id:0});assert.equal(r.state.result,'caught');assert.match(r.state.cause,/Smoke expired/);
});
check('camera observes ordinary attacks',()=>{
 const L=fixture({start:[2,1],guards:[{type:'static',at:[3,1],dir:'N'}],cams:[{wall:[3,0],mountDir:'S',dir:'S',type:'fixed'}]}),r=C.attempt(L,C.begin(L),{type:'attack',id:0});assert.equal(r.state.alarm,1);assert.equal(r.state.alarmEver,true);
});
const L=JSON.parse(fs.readFileSync(path.join(__dirname,'level_26_combat_prototype.json'))).level;
const results={stealth:C.search(L,{combat:false}),combat:C.search(L),oneKnockout:C.search(L,{minKnockouts:1,maxKnockouts:1}),bothKnockouts:C.search(L,{minKnockouts:2})};
for(const [name,r] of Object.entries(results))check('replay '+name,()=>{
 assert.equal(r.status,'win');assert.equal(r.actions,name==='stealth'?20:name==='oneKnockout'?20:18);let s=C.begin(L);
 for(const a of r.path){const q=C.attempt(L,s,a,{combat:name!=='stealth'});assert.equal(q.valid,true);s=q.state;}
 assert.equal(s.result,'win');assert.equal(s.t,r.actions);assert.equal(C.count(s.defeated),r.knockouts);
});
check('stealth route matches original engine state at every step',()=>{
 let original=B.begin(L),combat=C.begin(L);
 for(const a of results.stealth.path){original=B.attempt(L,original,a).state;combat=C.attempt(L,combat,a,{combat:false}).state;const {defeated,...rest}=combat;assert.equal(defeated,0);assert.deepEqual(rest,original);}
 assert.equal(B.search(L).actions,results.stealth.actions);
});
const report={revision:2,attackMovement:'Player moves onto the defeated guard current node in one action',scope:'Offline combat prototype; no Unity integration',layout:'Exact original Level 26 layout, objects, key, door and schedules retained',testsPassed:checks,results};
fs.writeFileSync(path.join(__dirname,'validation_and_solutions.json'),JSON.stringify(report,null,2));
console.log(checks+' checks passed. '+JSON.stringify(Object.fromEntries(Object.entries(results).map(([k,r])=>[k,{actions:r.actions,knockouts:r.knockouts,waits:r.waits}]))));
