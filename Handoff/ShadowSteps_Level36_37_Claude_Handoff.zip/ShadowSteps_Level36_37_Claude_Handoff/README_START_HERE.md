# Shadow Steps — LEVEL-36 & LEVEL-37 handoff kit

This package contains the latest independently tested level candidates from the ChatGPT design sessions. No Unity project files were modified here.

## Quick start

1. Open `CLAUDE_CODE_HANDOFF.md` and give its instructions to Claude Code from your Unity project in VS Code.
2. Point Claude to the two **original JSON** files under `Level36/` and `Level37/`. The combined JSON is included only for convenience.
3. Before editing stage geometry, run the independent checks: `python3 validate_sample_routes.py` (Python 3, standard library only).
4. Import as new LEVEL-36 and LEVEL-37 and run the Unity/C# authoritative solver.
5. Open the included HTML prototypes in a browser for visual/gameplay references (they are not Unity scene files).

## Included levels

- **LEVEL-36: Garden Gambit** — 9×9, 19 nodes, 2 rotating guards, compulsory key and exit door. Representative 8-action KO route and 12-action non-KO route.
- **LEVEL-37: The Locked Flank V2** — 9×9, 24 nodes, static main guard, protected 3-node ping-pong patrol, optional key/locked gate. Representative 8-action gate route and two 12-action no-key routes.

The 8/12-action counts are results of independent local checks, **not the official Unity par**. All implementation decisions and authoritative checks are detailed in `CLAUDE_CODE_HANDOFF.md`.
