# Shadow Steps — Claude Code handoff: LEVEL-36 and LEVEL-37

**Status:** Candidate stage definitions verified in independent Python tests and a browser prototype. **Not imported, compiled or validated with the Unity C# authoritative solver.**

## First action

Import the exact two JSON candidates from this kit as new main-campaign stages **LEVEL-36** and **LEVEL-37**. Inspect the existing Unity importer, stage registry, stage schema, solver and rendering code before modifying anything. Do **not** overwrite LEVEL-30 or any prior stage. The `base` keys are inheritance/template hints from the handover JSON schema; they do not identify the levels to overwrite.

The authoritative inputs are:
- `Level36/ShadowSteps_LEVEL-36_Garden_Gambit.json`
- `Level37/ShadowSteps_LEVEL-37_The_Locked_Flank_V2.json`

`Levels_36_37_Candidates.json` combines both unchanged objects. Never use the earlier Courtyard Trap (LEVEL-36) or Locked Flank V1 (LEVEL-37) candidates in their place.

## Shipped mechanics to preserve

- Portrait, turn-based graph gameplay; every counted action is movement to the next adjacent graph node. Edges across a single `-`/`|` walkway cell also cost only one action. No diagonal movement, no WAIT.
- Knockout when entering a guard's occupied node from behind or the side, **never from the front**. KO consumes one counted action; guard is removed for the rest of the attempt.
- Guard vision: up to **two grid squares straight ahead**, blocked by `#` walls, `X` solid cover, locked doors, and Smoke. Evaluate the player's destination with the **current and next** guard phase; physical collisions and edge-swaps are fatal.
- Rotating guard turns 90° after each counted action. `pingPong` guard advances one node per counted action, reversing immediately at route endpoints; no pause.
- Key is collected on entering its node. A locked door is a connection traversed only with the key, then remains unlocked for the attempt. Other movement connections do not automatically become doors.
- `.` graph node; `-` horizontal walkway; `|` vertical walkway; `+` both; `_` empty sight-permeable ground; `X` cover; `#` wall. Every walkway must have valid end nodes; connection length at most 2 grid squares.
- Global camera rule, for unrelated levels: 70° cone with **3-grid-square depth measured from wall face**. Neither of these two levels has cameras. Do not inadvertently revert this rule.
- Do not invent new guard-immunity flags, knockdown animations that change turn timing, WAIT actions, LOS rules, key behavior, or parser glyphs.

## LEVEL-36 — Garden Gambit (latest V1 candidate)

- Original 9×9 grid; **19 walkable nodes**, four `X` solid-cover cells; 2 stationary-position rotating guards.
- Start `[0,4]`, exit `[8,4]`; key `[2,0]`; the **only locked door** is edge `[6,4]`–`[8,4]` leading to the exit.
- `g1` rotating at `[4,4]`, initially East, clockwise. `g2` rotating at `[6,2]`, initially South, clockwise.
- Puzzle aim: collect the compulsory key, choose a quicker knockout through the upper approach or a longer clean circuit around the lower garden.
- Independently tested sample routes (not official pars):
  - **8 actions / 1 KO:** `[0,2]→[2,2]→[2,0]` (key) `→[4,0]→[6,0]→[6,2]` (KO `g2`) `→[6,4]→[8,4]` (unlock exit door).
  - **12 actions / 0 KO:** `[0,2]→[2,2]→[2,0]` (key) `→[2,2]→[2,4]→[2,6]→[2,8]→[4,8]→[6,8]→[6,6]→[6,4]→[8,4]`.
- Do not make the door optional or give the player a free knockout on the opening move. If the Unity solver finds an unintended faster/easier solution, report it rather than silently changing geometry.

## LEVEL-37 — The Locked Flank (latest V2, protected patrol)

- Original 9×9 grid; **24 walkable nodes** and one `X` cover cell, one `#` wall.
- Start `[0,4]`; exit `[6,2]`; optional key `[4,6]`; locked gate edge `[6,6]`–`[8,6]`.
- Main `g1`: **static**, at `[6,4]` facing West. This guard occupies the approach to the exit and must be knocked out by entering `[6,4]` from `[8,4]` (from behind); a direct front KO is illegal.
- Upper `g2`: **pingPong**, route `[2,2]→[3,2]→[4,2]→reverse`, initially East, offset 0. This guard is *not* rotating.
- **Critical mechanic:** `g2` is impossible to knock out because the three-node patrol is a separate graph component: the player can **never** reach any of the guard's patrol nodes, even after the gate is unlocked. `g2` still sees into player-accessible locations; its facing and timing still affect upper approaches and the exit. **Do not add an invulnerable flag**; keep the geometry-based protection. Do not accidentally reconnect the disconnected patrol through a decorative line, parser change or layout redesign.
- Independently tested sample routes (not official pars):
  - **8 actions, key + gate:** `[2,4]→[2,6]→[4,6]` (key) `→[6,6]→[8,6]` (gate) `→[8,4]→[6,4]` (KO `g1`) `→[6,2]`.
  - **12 actions, lower detour, no key:** `[0,2]→[0,4]→[2,4]→[2,6]→[2,8]→[4,8]→[6,8]→[8,8]→[8,6]→[8,4]→[6,4]` (KO `g1`) `→[6,2]`.
  - **12 actions, upper detour, no key:** `[0,2]→[0,0]→[2,0]→[4,0]→[6,0]→[8,0]→[8,2]→[8,0]→[8,2]→[8,4]→[6,4]` (KO `g1`) `→[6,2]`. The repeat movement is permitted for syncing, but **WAIT is not permitted**.
- A no-knockout solution should not exist for LEVEL-37. Verify this with the authoritative solver; do not assume from the browser demonstration alone.

## Visual integration

- Use existing `Assets/_ShadowSteps/Art2D/Sprites/` assets in the Unity project: courtyard/background art, Suit-Faceless player, Blue-Guard directional sprites, cream wall segments, green bush/planter sprites, and the door and HUD renderer.
- Map gameplay `X` to actual impassable bush/cover art, and `#` to existing wall art. Decorative wall/pole mount artwork must **not** create new solid graph nodes or visual connections that do not exist in the JSON.
- These two stages are 9×9. **Do not force horizontal panning** just because future stages may use it. Fit the whole board in the portrait view if reasonably legible; don't crop the puzzle or distort the level geometry.
- HTML files are self-contained **reference prototypes**, not drop-in Unity source. PNG files are visual checkpoints, not gameplay authority.

## Validation checklist — run in Unity before shipping

1. Parse the files with the game's actual stage importer; all rows of each stage are equally sized, graph edges legal and obstacle/wall cells correct.
2. Confirm `LEVEL-36` and `LEVEL-37` have distinct IDs in the campaign and do not overwrite levels 1–35.
3. Execute the authoritative C# solver for the shortest winning route, no-WAIT guard collision rules, front KO rejection and pre/post-turn vision timing.
4. Replay the two documented LEVEL-36 paths and three LEVEL-37 paths step-by-step in Unity and compare the result with the local checks. Investigate all discrepancies.
5. LEVEL-36: key should be mandatory; verify shorter KO vs longer no-KO route, door unlock and guard rotations.
6. LEVEL-37: the upper `g2` patrol must be unable to occupy any player-reachable component, with the gate either open or closed, and must never be killable. It must still threaten reachable nodes via vision. `g1` should remain a required KO from behind.
7. Ensure front attacks are illegal; no end-phase collisions or edge-swap loopholes. Confirm all three LEVEL-37 routes work without WAIT.
8. Have the solver **compute** official par and star thresholds, and inspect any unexpected shortcuts or unsolvable states. Avoid blindly copying 8 or 12 as authoritative optimal scores.
9. Keep JSON geometry unchanged unless a mismatch is found. Report the proposed fix and affected routes before editing level design.
10. Provide portrait Game-view screenshots for both levels and a short report with solver outcomes and any changes.

## Deliverable

A playable LEVEL-36 and LEVEL-37 in the existing Unity project, plus solver results, exact modified file paths and screenshots. **Stop after these two levels; do not auto-generate Levels 38–50.**
