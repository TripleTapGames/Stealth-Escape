# Level 37 V2 — Protected Patrol

- 9 × 9; 24 playable nodes; 2 guards (one static, one pingPong); 1 key; 1 locked gate.
- The upper guard g2 patrols (2, 2) → (3, 2) → (4, 2) → reverse.
- The guard-only subgraph has exactly 3 nodes with zero connections to any start-reachable node, **even after the gate opens**. Therefore the upper guard cannot be knocked out by the normal edge-based knockout rules; no immunity mechanic was added.
- The patroller sees the upper-left entry at certain phases and the exit at others, so it cannot be ignored.
- Main guard g1 stays at [6,4], faces West, and must be knocked out from behind at [8,4] to reach [6,2].
- Independent BFS result: gate + key route 8 actions; no-key lower detour 12 actions; no-key upper path 12 actions.
- This is independent Python validation, **not** the Unity authoritative solver.
- All valid walkway cells have both endpoint nodes; both guards use legal route positions.

## Fast route
1. [2, 4]
2. [2, 6]
3. [4, 6]
4. [6, 6]
5. [8, 6]
6. [8, 4]
7. [6, 4] — KO g1
8. [6, 2]

## No-key lower detour
1. [0, 2]
2. [0, 4]
3. [2, 4]
4. [2, 6]
5. [2, 8]
6. [4, 8]
7. [6, 8]
8. [8, 8]
9. [8, 6]
10. [8, 4]
11. [6, 4] — KO g1
12. [6, 2]

## No-key upper route
1. [0, 2]
2. [0, 0]
3. [2, 0]
4. [4, 0]
5. [6, 0]
6. [8, 0]
7. [8, 2]
8. [8, 0]
9. [8, 2]
10. [8, 4]
11. [6, 4] — KO g1
12. [6, 2]
