#!/usr/bin/env python3
"""Independent sample-route and graph validation for Shadow Steps level 36/37.
This is not the official Unity C# solver. No external dependencies.
"""
import json, pathlib
from collections import deque

ROOT=pathlib.Path(__file__).parent
D={'N':(0,-1),'E':(1,0),'S':(0,1),'W':(-1,0)}
F='NESW'
SOURCES={
 'LEVEL-36':'Level36/ShadowSteps_LEVEL-36_Garden_Gambit.json',
 'LEVEL-37':'Level37/ShadowSteps_LEVEL-37_The_Locked_Flank_V2.json'
}
ROUTES=json.loads((ROOT/'Representative_Routes.json').read_text())

def verify(level, route):
 rows=level['rows']; H=len(rows); W=len(rows[0]); nodes={(x,y) for y,row in enumerate(rows) for x,ch in enumerate(row) if ch=='.'}
 assert 0<W<=16 and 0<H<=16 and all(len(row)==W for row in rows)
 assert all(set(row)<={'#','X','.','-','|','+','_'} for row in rows)
 assert tuple(level['start']) in nodes and tuple(level['exit']) in nodes
 def cell(p):
  x,y=p
  return rows[y][x] if 0<=x<W and 0<=y<H else '#'
 adj={p:set() for p in nodes}
 for p in nodes:
  for dx,dy in D.values():
   for k in (1,2):
    q=(p[0]+k*dx,p[1]+k*dy); c=cell(q)
    if c=='.': adj[p].add(q);break
    if c not in (('-','+') if dx else ('|','+')):break
 for y,row in enumerate(rows):
  for x,c in enumerate(row):
   if c in '-+':assert (x-1,y) in nodes and (x+1,y) in nodes, (x,y,'bad horizontal walkway')
   if c in '|+':assert (x,y-1) in nodes and (x,y+1) in nodes, (x,y,'bad vertical walkway')
 doors={frozenset((tuple(d['a']),tuple(d['b']))) for d in level['doors']}
 for door in doors:
  a,b=tuple(door);assert b in adj[a],('invalid door edge',a,b)
 cuts={frozenset((tuple(a),tuple(b))) for a,b in level['cuts']}
 for edge in cuts:
  a,b=tuple(edge);adj[a].discard(b);adj[b].discard(a)
 def guard(g,t):
  route=[tuple(p) for p in g['route']]; kind=g['kind']
  if kind=='static':return route[0],g['facing']
  if kind=='rotating':return route[0], F[(F.index(g['facing'])+ t*(1 if g['clockwise'] else -1))%4]
  if kind=='pingPong':ix=list(range(len(route)))+list(range(len(route)-2,0,-1))
  elif kind=='loop':ix=list(range(len(route)))
  else:raise ValueError(kind)
  n=(t+g.get('offset',0))%len(ix); curr=route[ix[n]]
  if t==0 and g.get('offset',0)==0:return curr,g['facing']
  prev=route[ix[(n-1)%len(ix)]]; dd=(curr[0]-prev[0],curr[1]-prev[1])
  facing=next(k for k,(dx,dy) in D.items() if dx*dd[0]+dy*dd[1]>0)
  return curr,facing
 def sight(g,t,open_):
  pos,facing=guard(g,t);dx,dy=D[facing];out=[]
  for k in (1,2):
   nxt=(pos[0]+k*dx,pos[1]+k*dy); previous=(pos[0]+(k-1)*dx,pos[1]+(k-1)*dy)
   if cell(nxt) in '#X':break
   # Doors are graph edges and can span a walkway. If the ray crosses
   # the closed door link between its node endpoints, stop.
   for edge in doors:
    ends=tuple(edge)
    if not open_ and (previous in edge or nxt in edge):
     a,b=ends
     if a[1]==b[1]==pos[1] and dx and min(a[0],b[0])<=nxt[0]<=max(a[0],b[0]) and min(a[0],b[0])<=previous[0]<=max(a[0],b[0]):
      return out
     if a[0]==b[0]==pos[0] and dy and min(a[1],b[1])<=nxt[1]<=max(a[1],b[1]) and min(a[1],b[1])<=previous[1]<=max(a[1],b[1]):
      return out
   if nxt in nodes:out.append(nxt)
  return out
 keynode=tuple(level['key']) if level['key'] is not None else None
 p=tuple(level['start']); foundkey=False; opened=False; dead=set(); kills=[]
 for t,loc in enumerate(route):
  q=tuple(loc)
  assert q in adj[p],(t,'unconnected move',p,q)
  door=frozenset((p,q)) in doors
  assert not door or foundkey or opened,(t,'locked door',p,q)
  hit=[]
  for g in level['guards']:
   if g['id'] in dead:continue
   gp,facing=guard(g,t)
   if gp==q:
    dx,dy=D[facing]
    assert (p[0]-q[0])*dx+(p[1]-q[1])*dy<=0,(t,'front KO',g['id'])
    hit.append(g['id'])
  dead.update(hit);kills.extend(hit)
  for g in level['guards']:
   if g['id'] in dead:continue
   gp,_=guard(g,t);gp2,_=guard(g,t+1)
   assert q!=gp2,(t,'enemy occupation',g['id'])
   assert not(p==gp2 and q==gp),(t,'edge swap',g['id'])
   assert q not in sight(g,t,opened),(t,'sighted before update',g['id'])
   assert q not in sight(g,t+1,opened or door),(t,'sighted after update',g['id'])
  p=q;foundkey=foundkey or q==keynode; opened=opened or door
 assert p==tuple(level['exit']),('did not reach exit',p)
 return {'actions':len(route),'knockouts':kills,'key':foundkey,'opened_gate':opened,'nodes':len(nodes),'dimensions':(W,H)}

def accessible_nodes(level, unlocked=True):
 rows=level['rows']; nodes={(x,y) for y,row in enumerate(rows) for x,c in enumerate(row) if c=='.'}
 cuts={frozenset((tuple(a),tuple(b))) for a,b in level['cuts']}
 doors={frozenset((tuple(d['a']),tuple(d['b']))) for d in level['doors']}
 def cell(p):
  x,y=p;return rows[y][x] if 0<=y<len(rows) and 0<=x<len(rows[0]) else '#'
 q=deque([tuple(level['start'])]);seen=set(q)
 while q:
  p=q.popleft()
  for dx,dy in D.values():
   for k in (1,2):
    nxt=(p[0]+k*dx,p[1]+k*dy);c=cell(nxt)
    if c=='.':
     edge=frozenset((p,nxt))
     if edge not in cuts and (unlocked or edge not in doors) and nxt not in seen: seen.add(nxt);q.append(nxt)
     break
    if c not in (('-','+') if dx else ('|','+')):break
 return seen

if __name__=='__main__':
 for code,path in SOURCES.items():
  level=json.loads((ROOT/path).read_text())[0]
  for title,route in ROUTES[code].items():
   info=verify(level,route)
   print(f'PASS {code}: {title}: {info["actions"]} actions, KOs={info["knockouts"]}')
  if code=='LEVEL-36':
   assert tuple(level['key']) in accessible_nodes(level,False)
  if code=='LEVEL-37':
   patrol={tuple(p) for p in level['guards'][1]['route']}
   assert patrol.isdisjoint(accessible_nodes(level,True))
   assert patrol.isdisjoint(accessible_nodes(level,False))
   assert all('g2' not in verify(level,route)['knockouts'] for route in ROUTES[code].values())
   print('PASS LEVEL-37: upper guard patrol disconnected with gate closed AND open')
 print('All independent sample checks passed. Run the C# solver before shipping.')
