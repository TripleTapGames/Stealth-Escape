Independent domain audit harness. Build the current Unity CoreTestRunner first if missing or stale; the project already provides Tools/run_core_tests.sh. Do not use a stale DLL after changing engine code.

From this review folder:
dotnet run --project verification/NoWaitAudit.csproj -- levels_v4_no_wait.json KNOCKOUT_NO_WAIT_VALIDATION.json

This uses the existing CoreTestRunner.dll at /tmp/shadowsteps_coretests/bin. Override with -p:ShadowStepsRunner=/absolute/path/CoreTestRunner.dll if needed. It does not rebuild or edit Unity source, and does not run Editor tests. It checks structure, scores, no-WAIT rejection, exact per-action movement/cost and normal/Ghost winning replays on every level.
