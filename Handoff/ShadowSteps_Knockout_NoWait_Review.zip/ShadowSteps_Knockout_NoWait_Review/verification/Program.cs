using ShadowSteps.V3;
using ShadowSteps.Data;
using System.Text.Json;
using System.Security.Cryptography;

static void Require(bool condition,string why) { if(!condition)throw new Exception(why); }
var bytes=File.ReadAllBytes(args[0]);
var pack=StageJson.Parse(System.Text.Encoding.UTF8.GetString(bytes));
var structure=StageValidator.ValidatePack(pack.Stages,new StageValidationOptions {RunSolver=false});
Require(structure.IsValid,structure.ToString());
var rows=new List<object>();
var replayed=0;
foreach(var s in pack.Stages) {
 Require(s.WaitLimit==0,s.Code+" WAIT not disabled");
 var result=StageSolver.Solve(s,new SolveOptions{Mode=StageMode.Knockout,MaxWaits=0,MaxActions=256,StateLimit=500000});
 Require(result.Found&&!result.HitLimit,s.Code+" no verified solution");
 Require(result.CountedActions==s.KnockoutPar,s.Code+" scoring mismatch");
 Require(s.KnockoutThreeStarActions==StageScoring.ThreeStarThreshold(result.CountedActions),s.Code+" three-star mismatch");
 Require(s.KnockoutTwoStarActions==StageScoring.TwoStarThreshold(result.CountedActions),s.Code+" two-star mismatch");
 StageState Replay(List<StageAction> actions,bool ghost) {
  var state=StageState.Initial(s,StageMode.Knockout);
  foreach(var a in actions) {
   var denied=StageRules.TryApply(s,state,StageAction.Wait);
   Require(!denied.Valid&&denied.Reason==RejectReason.NoWaitsLeft,s.Code+" WAIT accepted");
   Require(denied.After.Key(s.Period,true)==state.Key(s.Period,true)&&denied.After.T==state.T,s.Code+" WAIT changed state");
   Require(a.Kind!=StageActionKind.Wait,s.Code+" WAIT in solution");
   var o=StageRules.TryApply(s,state,a);
   Require(o.Valid,s.Code+" replay invalid: "+a.Token);
   bool counted=a.Kind==StageActionKind.Move||a.Kind==StageActionKind.Knockout;
   Require(o.After.T-state.T==(counted?1:0),s.Code+" wrong action cost");
   Require(o.After.Player.ManhattanDistance(state.Player)==(counted?1:0),s.Code+" standing action advanced time");
   state=o.After;
  }
  Require(state.Result==StageResult.Won,s.Code+" replay did not win");
  if(ghost)Require(!state.AlarmEver,s.Code+" ghost replay alarmed");
  return state;
 }
 var final=Replay(result.Actions,false);
 var ghostResult=s.Cameras.Count>0?StageSolver.Solve(s,new SolveOptions{Mode=StageMode.Knockout,MaxWaits=0,AlarmFreeOnly=true,MaxActions=256,StateLimit=500000}):null;
 Require(ghostResult==null||!ghostResult.HitLimit,s.Code+" Ghost search limit");
 if(ghostResult?.Found==true)Replay(ghostResult.Actions,true);
 Require(s.GhostOffered==(ghostResult?.Found==true),s.Code+" Ghost flag mismatch");
 var noKO=s.Guards.Count>0?StageSolver.Solve(s,new SolveOptions{Mode=StageMode.Knockout,MaxWaits=0,MaxKnockouts=0,MaxActions=256,StateLimit=500000}):null;
 rows.Add(new {id=s.Id,code=s.Code,title=s.Title,par=result.CountedActions,threeStar=s.KnockoutThreeStarActions,twoStar=s.KnockoutTwoStarActions,
  actions=result.Actions.Select(a=>a.Token).ToArray(),knockouts=final.DefeatedCount,guards=s.Guards.Count,waits=final.WaitsUsed,waitRejectedWithoutStateChange=true,
  replayWon=true,ghostOffered=s.GhostOffered,ghostActions=ghostResult?.Found==true?ghostResult.Actions.Select(a=>a.Token).ToArray():null,
  shortestWithoutKnockout=s.Guards.Count==0?result.CountedActions:noKO.Found?noKO.CountedActions:-1,noKnockoutSearchHitLimit=noKO?.HitLimit??false,
  statesExplored=result.StatesExplored});
 replayed++;
 Console.WriteLine(s.Code+" verified: "+result.CountedActions+" moves/knockouts, "+final.DefeatedCount+" KO, zero WAIT");
}
var report=new {scope="Review copy of current Unity V4 levels; actual compiled C# engine and data types. Not an Editor/Game-view test or a live-project modification.",
 mode="knockout",waitEnabled=false,sourcePackSha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),
 structuralErrors=structure.ErrorCount,structuralWarnings=structure.WarningCount,structuralReport=structure.ToString(),
 stages=rows.Count,replayedWins=replayed,allStoredKnockoutScoresMatched=true,allWaitAttemptsRejectedWithoutStateChange=true,
 allCountedActionsMovedOneNode=true,allGadgetsRemainedFree=true,allOfferedGhostRoutesReplayed=true,editorValidation="pending",levels=rows};
File.WriteAllText(args[1],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true})+"\n");
Console.WriteLine("VERIFIED "+replayed+"/"+rows.Count);
