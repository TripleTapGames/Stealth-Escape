Shadow Steps: current Unity levels, Knockout only, no WAIT.

Read START_HERE_NO_WAIT.txt first. This package contains a review candidate, not an installed Unity change. The live project has not been edited.

levels_v4_no_wait.json: the 35 current stages with no-WAIT compatibility adjustments and fresh Knockout scoring.
CHANGE_REVIEW.json / levels_v4_review.diff: every edit, original source hash, revised pars and the single positional change (LEVEL-19 start).
KNOCKOUT_NO_WAIT_VALIDATION.json: current C# engine checks; 35/35 winning replays, no WAIT, scores and Ghost routes verified.
MODES_AUDIT_NO_WAIT.json: mode comparison only; legacy Stealth is not the shipping target.
verification/: reproducible audit source referencing the user's current core runner; no compiled binaries are bundled.
manifest.json: package checksums.

Next: review the compatibility diff, then review the harder/funner level designs one level at a time. The integration instruction also identifies the hidden long-press/Space WAIT inputs that still need removal in Unity.
